import{c as r,_ as $,L,D as S,E as s,o as N,d as z,e as o,G as T,g as a,h as i,t as l}from"./logo-sunshine-45-B_jr9vlN.js";import{I as C,N as M}from"./Notification-DbmabxUE.js";/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=[["path",{d:"M17.925 20.056a6 6 0 0 0-11.851.001",key:"z69sun"}],["circle",{cx:"12",cy:"11",r:"4",key:"1gt34v"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],U=r("circle-user-round",H);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8",key:"5wwlr5"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",key:"r6nss1"}]],R=r("house",x);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const V=[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]],I=r("lock",V);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]],A=r("log-out",q);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=[["path",{d:"M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",key:"1i5ecw"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],P=r("settings",B);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]],E=r("shield",D);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]],G=r("star",O),j={components:{ThemeToggle:S,Notification:M,Home:R,Lock:I,Layers:L,Star:G,Settings:P,Shield:E,Info:C,CircleUserRound:U,LogOut:A},created(){console.log("Header mounted!")},mounted(){const e=globalThis.location.pathname.replace(/\/$/,"")||"/",n=document.querySelectorAll(".navbar-sunshine a[href]");for(const t of n){const c=t.getAttribute("href");!c||c==="#"||(new URL(c,globalThis.location.href).pathname.replace(/\/$/,"")||"/")!==e||t.classList.add("active")}},methods:{logout(){const e=Date.now().toString(),n=new URL("/logout",globalThis.location.href),t=new XMLHttpRequest,c=()=>{globalThis.location.replace(n.toString())};t.open("GET","/",!0,"sunshine-logout",e),t.setRequestHeader("Cache-Control","no-store"),t.onload=c,t.onerror=c,t.ontimeout=c,t.timeout=5e3,t.send()}}},X={class:"navbar navbar-expand-lg navbar-sunshine"},F={class:"container-fluid"},J={class:"collapse navbar-collapse",id:"navbarSupportedContent"},K={class:"navbar-nav me-auto mb-2 mb-lg-0"},Q={class:"nav-item"},W={class:"nav-link",href:"./"},Y={class:"nav-item"},Z={class:"nav-link",href:"./pin"},oo={class:"nav-item"},no={class:"nav-link",href:"./apps"},eo={class:"nav-item"},to={class:"nav-link",href:"./config"},so={class:"nav-item"},ao={class:"nav-link",href:"./troubleshooting"},co={class:"navbar-nav ms-auto mb-2 mb-lg-0"},io={class:"nav-item"},lo={class:"nav-item dropdown"},ro={class:"nav-link dropdown-toggle",type:"button",id:"navbarUserMenu","data-bs-toggle":"dropdown","aria-expanded":"false","aria-label":"User menu",title:"User menu"},ho={class:"dropdown-menu dropdown-menu-end","aria-labelledby":"navbarUserMenu"},uo={class:"dropdown-item d-flex align-items-center",href:"./password"};function _o(e,n,t,c,h,d){const u=s("Home"),_=s("Lock"),p=s("Layers"),m=s("Settings"),g=s("Info"),v=s("ThemeToggle"),b=s("CircleUserRound"),f=s("Shield"),k=s("LogOut"),y=s("Notification");return N(),z("div",null,[o("nav",X,[o("div",F,[n[2]||(n[2]=o("a",{class:"navbar-brand",href:"./",title:"Sunshine"},[o("img",{src:T,height:"45",alt:"Sunshine"})],-1)),n[3]||(n[3]=o("button",{class:"navbar-toggler",type:"button","data-bs-toggle":"collapse","data-bs-target":"#navbarSupportedContent","aria-controls":"navbarSupportedContent","aria-expanded":"false","aria-label":"Toggle navigation"},[o("span",{class:"navbar-toggler-icon"})],-1)),o("div",J,[o("ul",K,[o("li",Q,[o("a",W,[a(u,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.home")),1)])]),o("li",Y,[o("a",Z,[a(_,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.pin")),1)])]),o("li",oo,[o("a",no,[a(p,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.applications")),1)])]),o("li",eo,[o("a",to,[a(m,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.configuration")),1)])]),o("li",so,[o("a",ao,[a(g,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.troubleshoot")),1)])])]),o("ul",co,[o("li",io,[a(v)]),o("li",lo,[o("button",ro,[a(b,{size:18,class:"icon"})]),o("ul",ho,[o("li",null,[o("a",uo,[a(f,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.password")),1)])]),n[1]||(n[1]=o("li",null,[o("hr",{class:"dropdown-divider"})],-1)),o("li",null,[o("button",{type:"button",class:"dropdown-item d-flex align-items-center",onClick:n[0]||(n[0]=(...w)=>d.logout&&d.logout(...w))},[a(k,{size:18,class:"icon"}),i(" "+l(e.$t("navbar.logout")),1)])])])])])])])]),a(y)])}const go=$(j,[["render",_o]]);export{go as N,E as S,P as a};

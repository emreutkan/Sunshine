import{c as t,a as r,i as a}from"./logo-sunshine-45-B_jr9vlN.js";import{N as c}from"./Navbar-DVpbAc4C.js";import{a as s}from"./fetch_utils-BTKQ2z-h.js";import"./Notification-DbmabxUE.js";/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=[["path",{d:"m15 17 5-5-5-5",key:"nf172w"}],["path",{d:"M4 18v-2a4 4 0 0 1 4-4h12",key:"jmiej9"}]],y=t("forward",l);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=[["line",{x1:"4",x2:"20",y1:"9",y2:"9",key:"4lhtct"}],["line",{x1:"4",x2:"20",y1:"15",y2:"15",key:"vyu0kd"}],["line",{x1:"10",x2:"8",y1:"3",y2:"21",key:"1ggp8o"}],["line",{x1:"16",x2:"14",y1:"3",y2:"21",key:"weycgp"}]],u=t("hash",p);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]],m=t("monitor",d);let h=r({components:{Navbar:c,Forward:y,Hash:u,Monitor:m},inject:["i18n"],methods:{registerDevice(v){let n=document.querySelector("#pin-input").value,i=document.querySelector("#name-input").value;document.querySelector("#status").innerHTML="";let o=JSON.stringify({pin:n,name:i});s("./api/pin",{method:"POST",headers:{"Content-Type":"application/json"},body:o}).then(e=>e.json()).then(e=>{e.status===!0?(document.querySelector("#status").innerHTML=`<div class="alert alert-success" role="alert">${this.i18n.t("pin.pair_success")}</div>`,document.querySelector("#pin-input").value="",document.querySelector("#name-input").value=""):document.querySelector("#status").innerHTML=`<div class="alert alert-danger" role="alert">${this.i18n.t("pin.pair_failure")}</div>`})}}});a(h);

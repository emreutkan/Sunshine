import{c as o,_ as a,D as t,E as c,o as r,d as i,e,G as _,g as p}from"./logo-sunshine-45-B_jr9vlN.js";/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=[["path",{d:"m10 17 5-5-5-5",key:"1bsop3"}],["path",{d:"M15 12H3",key:"6jk70r"}],["path",{d:"M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4",key:"u53s6r"}]],N=o("log-in",d),l={components:{ThemeToggle:t}},m={class:"navbar navbar-sunshine"},h={class:"container-fluid"};function g(u,s,v,f,b,k){const n=c("ThemeToggle");return r(),i("nav",m,[e("div",h,[s[0]||(s[0]=e("span",{class:"navbar-brand",title:"Sunshine"},[e("img",{src:_,height:"45",alt:"Sunshine"})],-1)),p(n)])])}const $=a(l,[["render",g]]);export{N as L,$ as N};

import{C as a,a as o,i as p}from"./logo-sunshine-45-B_jr9vlN.js";import{N as m,L as s}from"./NavbarSimple-Bc4b1smm.js";a();const t=o({components:{LogIn:s,NavbarSimple:m}});p(t);

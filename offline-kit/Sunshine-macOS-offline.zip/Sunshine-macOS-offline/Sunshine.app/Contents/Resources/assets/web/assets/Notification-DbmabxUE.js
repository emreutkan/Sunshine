import{c as d,_ as p,o,d as a,F as m,k as u,j as y,K as _,z as k,n as g,J as h,e as l,t as f}from"./logo-sunshine-45-B_jr9vlN.js";/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]],x=d("circle-alert",C);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]],I=d("circle-check-big",v);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const K=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 16v-4",key:"1dtifu"}],["path",{d:"M12 8h.01",key:"e9boi3"}]],b=d("info",K);/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const A=[["path",{d:"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",key:"wmoenq"}],["path",{d:"M12 9v4",key:"juzpu7"}],["path",{d:"M12 17h.01",key:"p32p05"}]],N=d("triangle-alert",A),c=_({notifications:[],_nextId:1});function r(e,t,s){c.notifications.push({id:c._nextId++,type:e,message:null,title:null,messageKey:t,titleKey:s||null})}function $(e){return{danger:"AlertCircle",warning:"AlertTriangle",success:"CheckCircle",info:"Info"}[e]||"Info"}const V={error:(e,t)=>r("danger",e,t),warning:(e,t)=>r("warning",e,t),success:(e,t)=>r("success",e,t),info:(e,t)=>r("info",e,t)},w={components:{AlertCircle:x,AlertTriangle:N,CheckCircle:I,Info:b},setup(){function e(t){const s=c.notifications.findIndex(n=>n.id===t);s!==-1&&c.notifications.splice(s,1)}return{state:c,dismiss:e,iconFor:$}}},z={key:0,class:"notification-container"},B={class:"flex-grow-1"},M={key:0},F=["aria-label","onClick"];function T(e,t,s,n,L,j){return n.state.notifications.length>0?(o(),a("div",z,[(o(!0),a(m,null,u(n.state.notifications,i=>(o(),a("div",{key:i.id,class:k(["alert d-flex align-items-start gap-2 mb-2","alert-"+i.type]),role:"alert"},[(o(),g(h(n.iconFor(i.type)),{size:18,class:"icon flex-shrink-0 mt-1"})),l("div",B,[i.titleKey||i.title?(o(),a("div",M,[l("strong",null,f(i.titleKey?e.$t(i.titleKey):i.title),1)])):y("",!0),l("span",null,f(i.messageKey?e.$t(i.messageKey):i.message),1)]),l("button",{type:"button",class:"btn-close","aria-label":e.$t("_common.dismiss"),onClick:q=>n.dismiss(i.id)},null,8,F)],2))),128))])):y("",!0)}const E=p(w,[["render",T],["__scopeId","data-v-921526d4"]]);export{I as C,b as I,E as N,N as T,x as a,V as n};

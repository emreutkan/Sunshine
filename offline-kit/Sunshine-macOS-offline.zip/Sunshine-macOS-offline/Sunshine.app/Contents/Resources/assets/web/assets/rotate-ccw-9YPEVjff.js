import{c as t}from"./logo-sunshine-45-B_jr9vlN.js";/**
 * @license @lucide/vue v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],o=t("rotate-ccw",c);export{o as R};
